SELECT pgroonga_normalize('りんごとリンゴ',
                          'NormalizerNFKC100("unify_kana", true)');
