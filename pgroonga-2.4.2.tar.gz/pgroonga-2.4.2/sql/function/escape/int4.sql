SELECT pgroonga_escape(292929::int4);
SELECT pgroonga_escape(-292929::int4);
