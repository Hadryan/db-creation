SELECT pgroonga_escape(29::int2);
SELECT pgroonga_escape(-29::int2);
