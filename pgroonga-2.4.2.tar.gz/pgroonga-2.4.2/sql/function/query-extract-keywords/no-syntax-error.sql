SELECT pgroonga_query_extract_keywords('(Groonga');
