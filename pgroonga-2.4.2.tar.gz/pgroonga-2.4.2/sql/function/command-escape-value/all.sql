SELECT pgroonga_command_escape_value('a+B-c" \\あ\nいう');
