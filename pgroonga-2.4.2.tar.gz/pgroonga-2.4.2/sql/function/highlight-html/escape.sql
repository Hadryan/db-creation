SELECT pgroonga_highlight_html(
  '<p>Groonga is a fast and accurate full text search engine based on ' ||
  'inverted index.</p>',
  ARRAY['Groonga']);
