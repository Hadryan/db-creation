SELECT pgroonga_normalize('ЛИЦЕНЗИЯ', 'NormalizerNFKC100');
