SELECT pgroonga_escape('a+B-c< >あいう~*()"\\'':', '+-<>~*()"\\:');
