SELECT pgroonga_match_positions_character(
  '100㍉メートル',
  ARRAY['ミリ']);
