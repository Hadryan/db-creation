SELECT pgroonga_result_to_jsonb_objects(
  '[
     [0, 0.0, 0.0],
     [
       [
         [0],
         [["_id", "UInt32"]]
       ]
     ]
   ]'::jsonb);
