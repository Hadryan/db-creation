SELECT pgroonga_highlight_html(
  '100㍉メートル',
  ARRAY['ミリ']);
