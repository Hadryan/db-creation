SELECT pgroonga_tokenize('This is a pen.',
                         'unknown', 'value');
