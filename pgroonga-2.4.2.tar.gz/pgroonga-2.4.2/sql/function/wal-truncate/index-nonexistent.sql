SELECT pgroonga_wal_truncate('nonexistent');
