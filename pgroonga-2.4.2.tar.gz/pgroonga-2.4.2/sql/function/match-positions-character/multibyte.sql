SELECT pgroonga_match_positions_character(
  'Groongaは転置索引を用いた高速・高精度な全文検索エンジンであり、' ||
  '登録された文書をすぐに検索結果に反映できます。',
  ARRAY['検索']);
