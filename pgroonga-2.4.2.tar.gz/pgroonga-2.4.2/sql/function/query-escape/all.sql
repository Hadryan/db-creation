SELECT pgroonga_query_escape('a+B-c< >あいう~*()"\\'':');
