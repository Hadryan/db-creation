SELECT pgroonga_escape(true);
SELECT pgroonga_escape(false);
