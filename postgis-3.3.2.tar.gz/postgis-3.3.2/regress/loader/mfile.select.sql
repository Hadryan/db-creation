﻿select address, short_name, color from loadedshp order by 1;
