SELECT pgroonga_escape(292929292929::int8);
SELECT pgroonga_escape(-292929292929::int8);
