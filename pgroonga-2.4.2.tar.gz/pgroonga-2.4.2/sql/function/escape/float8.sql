SELECT pgroonga_escape(29.2929::float8);
SELECT pgroonga_escape(-29.2929::float8);
