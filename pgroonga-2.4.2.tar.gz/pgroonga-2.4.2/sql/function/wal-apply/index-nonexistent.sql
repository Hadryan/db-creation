SELECT pgroonga_wal_apply('nonexistent');
