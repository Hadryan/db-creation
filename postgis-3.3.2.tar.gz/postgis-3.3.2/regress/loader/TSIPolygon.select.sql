select ST_Asewkt(the_geom) from loadedshp ORDER BY gid;

