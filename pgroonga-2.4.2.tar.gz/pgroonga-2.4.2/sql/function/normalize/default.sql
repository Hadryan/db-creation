SELECT pgroonga_normalize('aBcDe 123');
