SELECT pgroonga_match_positions_byte(
  '100㍉メートル',
  ARRAY['ミリ']);
