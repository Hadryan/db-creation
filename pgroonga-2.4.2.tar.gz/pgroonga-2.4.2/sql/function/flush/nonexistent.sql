SELECT pgroonga_flush('pgroonga_index');
