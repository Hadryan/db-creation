SELECT pgroonga_is_writable();
SELECT pgroonga_set_writable(false);
SELECT pgroonga_is_writable();
SELECT pgroonga_set_writable(true);
SELECT pgroonga_is_writable();
